#ifndef NDIMENSIONPOINT_H
#define NDIMENSIONPOINT_H
#include <iostream>

template <typename T>
class n_dimension_point{
  private:
    T arr[10];
    int dimension;
  public:
    //constructors
    n_dimension_point();

    n_dimension_point(int d);

    n_dimension_point(T a[], int d);

    void operator =(const n_dimension_point p);

    //getter
    int getSize(){
      return dimension;
    }
    T getItem(int i){
      return arr[i];
    }

};

template <typename T>
n_dimension_point<T>::n_dimension_point(){
  dimension = 0;
  T t = T();
  arr[0] = t;
}

template <typename T>
n_dimension_point<T>::n_dimension_point(int d){
  dimension = d;
  T t = T();
  for (int i = 0; i < d; i++){
    arr[i] = t;
  }
}

template <typename T>
n_dimension_point<T>::n_dimension_point(T a[], int d){
  dimension = d;
  for (int i = 0; i < d; i++){
    arr[i] = a[i];
  }

}

template <typename T>
void n_dimension_point<T>::operator =(n_dimension_point p){
  dimension = p.getSize();
  for(int i = 0; i < p.getSize(); i++){
    arr[i] = p.getItem(i);
  }
}

template <typename T>
void n_dimension_point<T>::operator +=(n_dimension_point p){
  //find smaller array
  int sm = 0;
  if(p.getSize() > dimension)
    sm =1;
  if(sm == 1){
    for(int i = 0; i < dimension; i++){
      a[i]+=p.getItem();
    }
  }else{
    for(int i = 0; i < p.size(); i++){
      a[i]+=p.getItem();
    }
  }
}

template <typename T>
void n_dimension_point<T>::operator +(n_dimension_point p){
  n_dimension_pojnt tmp;
  tmp = this;
  tmp +=p;
  this = tmp;
}

template <typename T>
bool n_dimension_point<T>::operator ==(n_dimension_point p){
  if(dimension != p.size())
    return false;
  for(int i = 0; i < dimension; i++){
    if(a[i] != p.getItem(i))
      return false;
  }
  return true;
}

template <typename T>
double distance(point<T> pa, point<T> pb){
  double distance = 0;
  for(int i = 0; i < pa.getSize(); i++)}{
    distance += pow(pb.getItem(i) - pa.getItem(i), 2);
  }
}

//string - overload

int operator -(std::string sa, std::string sb){
  int difference = (int)(sa.front() - sb.front());
  return difference;
}

#endif //NDIMENSIONPOINT_H
