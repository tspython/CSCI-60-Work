#include "n_dimension_point.h"

/*
template <typename T>
n_dimension_point<T>::n_dimension_point(){
  dimension = 0;
  T t = T();
  arr[0] = t;
}

template <typename T>
n_dimension_point<T>::n_dimension_point(int d){
  dimension = d;
  T t = T();
  for (int i = 0; i < d; i++){
    arr[i] = t;
  }
}

template <typename T>
n_dimension_point<T>::n_dimension_point(T a[], int d){
  dimension = d;
  for (int i = 0; i < d; i++){
    arr[i] = a[i];
  }

}
*/
