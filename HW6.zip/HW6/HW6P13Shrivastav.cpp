#include <iostream>

template <typename T>
T abs(T a, T b);

template <typename T1>
template T1 frequent(T1 a[], std::size_t size);

template <typename T>
T abs(T a, T b){
  if(a - b > b -a) // must support > operator (comparative)
    return a-b;
  else
    return b-a;
}

template <typename T1>
template T1 frequent(T1 a[], std::size_t size){

  std::map<T1, int> m;

  for(int i = 0; i < size; i++){
    m[a[i]]++;
  }

  T1 greatest_T;
  int number_of = 0;
  for(auto e:m){
    if(e.second > number_of){
      greatest_T = e.first;
      number_of = e.second;
    }
  }
  return greatest_T;
}


int main(){
  return 0;
}
