#include <iostream>
#include <map>
#include <vector>
#include <set>
#include <fstream>
#include <algorithm>
using namespace std;

int main(){
  vector<string> vs;

  ifstream file;
  file.open("gentleseduction.txt");

  string word;
  while(file >> word){
    vs.push_back(word);
  }

  file.close();

  ofstream out("p1out.txt");

  //alphabetical sort
  sort(vs.begin(), vs.end());

  int count = 0;
  string words2 = vs[0];
  for(auto i:vs){
    if(i == words2)
      count++;
    else{
      out << words2 << ": " << count << endl;
      words2 = i;
      count = 1;
    }
  }

  //remove duplicates
  unique(vs.begin(), vs.end());

  return 0;
}
