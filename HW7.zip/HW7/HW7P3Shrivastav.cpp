#include <iostream>
#include <fstream>
//#include <algorithm>
#include <map>
#include <vector>
#include <string>
using namespace std;

int main(){
  map<int,pair<int,vector<string>>> mp;
  //int - score
  //pair<int, vector<string>>>
    // int - number f people who got the score
    //vector<string> - string of names who got that score

  ifstream file;
  file.open("scorename.txt");

  int count;
  string name;
  while(!file.eof()){
    file >> count;
    getline(file, name);
    mp[count].first++;
    mp[count].second.push_back(name);
  }


  int all_scores[11] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
  for(int i = 0; i < 11; i++){
    cout << all_scores[i];

    for(int j = 0; j < mp[i].first; j++)
      cout << 'x';

    cout << endl;
  }

  int score_input;
  cout << "Of which score would you like to see the names of?";
  cin >> score_input;

  for(auto i : mp[score_input].second){
    cout << i << ", ";
  }
	cout << endl;

  return 0;
}
